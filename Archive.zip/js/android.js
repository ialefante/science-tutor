$(document).ready(function(){
 $('#menu ul').addClass('hide');

 $("#header .btn").click(function(){
    $('#menu ul').toggleClass('hide');
 });
});
